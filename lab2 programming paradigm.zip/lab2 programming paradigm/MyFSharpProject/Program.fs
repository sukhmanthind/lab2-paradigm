﻿type Coach = {
    Name: string
    FormerPlayer: bool
}


type Stats = {
    Wins: int
    Losses: int
}


type Team = {
    Name: string
    Coach: Coach
    Stats: Stats
}


let teams = [
    { Name = "Lakers"; Coach = { Name = "shubhneet Singh"; FormerPlayer = true }; Stats = { Wins = 55; Losses = 27 } }
    { Name = "Paris"; Coach = { Name = "Dipanshu Aggarwal"; FormerPlayer = false }; Stats = { Wins = 53; Losses = 29 } }
    { Name = "Bulls"; Coach = { Name = "Davinder Gill"; FormerPlayer = true }; Stats = { Wins = 40; Losses = 42 } }
    { Name = "Heat"; Coach = { Name = "Sukhdeep singh"; FormerPlayer = false }; Stats = { Wins = 44; Losses = 38 } }
    { Name = "Barcelona"; Coach = { Name = "arshdeep singh"; FormerPlayer = true }; Stats = { Wins = 42; Losses = 40 } }
]


let successfulTeams = 
    teams 
    |> List.filter (fun team -> team.Stats.Wins > team.Stats.Losses)


let calculateSuccessPercentage team =
    let wins = float team.Stats.Wins
    let losses = float team.Stats.Losses
    (wins / (wins + losses)) * 100.0

let successPercentages = 
    teams 
    |> List.map (fun team -> (team.Name, calculateSuccessPercentage team))


printfn "Successful Teams:"
successfulTeams |> List.iter (fun team -> printfn "%s" team.Name)

printfn "\nSuccess Percentages:"
successPercentages |> List.iter (fun (name, percent) -> printfn "%s: %.2f%%" name percent)


//second question
type Cuisine =
    | Korean
    | Turkish

type MovieType =
    | Regular
    | IMAX
    | DBOX
    | RegularWithSnacks
    | IMAXWithSnacks
    | DBOXWithSnacks

type Activity =
    | BoardGame
    | Chill
    | Movie of MovieType
    | Restaurant of Cuisine
    | LongDrive of int * float

let calculateBudget (activity: Activity) =
    match activity with
    | BoardGame -> 0.0
    | Chill -> 0.0
    | Movie movieType ->
        match movieType with
        | Regular -> 12.0
        | IMAX -> 17.0
        | DBOX -> 20.0
        | RegularWithSnacks -> 17.0
        | IMAXWithSnacks -> 22.0
        | DBOXWithSnacks -> 25.0
    | Restaurant cuisine ->
        match cuisine with
        | Korean -> 70.0
        | Turkish -> 65.0
    | LongDrive (kilometers, fuelCost) ->
        float kilometers * fuelCost


let activity1 = Movie Regular
let activity2 = Restaurant Korean
let activity3 = LongDrive (100, 1)


let budget1 = calculateBudget activity1
let budget2 = calculateBudget activity2
let budget3 = calculateBudget activity3


let totalBudget = budget1 + budget2 + budget3


printfn "Budget for activity (Movie Regular): %.2f CAD" budget1
printfn "Budget for activity (Restaurant Korean): %.2f CAD" budget2
printfn "Budget for activity (Long Drive): %.2f CAD" budget3
printfn "Total Budget: %.2f CAD" totalBudget
